import turtle

screen = turtle.Screen()
square_turtle = turtle.Turtle()

sides = 4
angle = 90
length = 100  

for _ in range(sides):
    square_turtle.forward(length)
    square_turtle.right(angle)

screen.mainloop()
